package com.cg.obs.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Transaction")

public class Transactions {

	@Id
	@Column(name="Transaction_ID")
	@GeneratedValue(strategy=GenerationType.SEQUENCE , generator="myseqgen")
	@SequenceGenerator(name="myseqgen", sequenceName ="seq_transactionid", initialValue=1000)

	private int transaction_ID;
	
	@Column(name="Tran_description")
	private String tran_Description;
	
	@Column(name="DateofTransaction")
	private Date dateOfTransaction;
	
	@Column(name="TransactionType")
	private char transactionType;
	
	@Column(name="TranAmount")
	private double transactionAmount;
	
	@Column(name="Account_ID")
	private Long accountID;
	
	
	
	public int getTransaction_ID() {
		return transaction_ID;
	}
	public void setTransaction_ID(int transaction_ID) {
		this.transaction_ID = transaction_ID;
	}
	public String getTran_Description() {
		return tran_Description;
	}
	public void setTran_Description(String tran_Description) {
		this.tran_Description = tran_Description;
	}
	public Date getDateOfTransaction() {
		return dateOfTransaction;
	}
	public void setDateOfTransaction(Date dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}
	public Long getAccountID() {
		return accountID;
	}
	public void setAccountID(Long accountID) {
		this.accountID = accountID;
	}
	
	public char getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(char transactionType) {
		this.transactionType = transactionType;
	}
	public double getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(Double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	
	public Transactions(int transaction_ID, String tran_Description, Date dateOfTransaction, char transactionType,
			double transactionAmount, Long accountID) {
		super();
		this.transaction_ID = transaction_ID;
		this.tran_Description = tran_Description;
		this.dateOfTransaction = dateOfTransaction;
		this.transactionType = transactionType;
		this.transactionAmount = transactionAmount;
		this.accountID = accountID;
	}
	public Transactions() {
		super();
	}
	
	@Override
	public String toString() {
		return "Transactions [transaction_ID=" + transaction_ID + ", tran_Description=" + tran_Description
				+ ", dateOfTransaction=" + dateOfTransaction + ", transactionType=" + transactionType
				+ ", transactionAmount=" + transactionAmount + ", accountID=" + accountID + "]";
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + transaction_ID;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Transactions other = (Transactions) obj;
		if (transaction_ID != other.transaction_ID)
			return false;
		return true;
	}
	
	
	
}
